// UserSolution.java

class UserSolution {
	public void init(int L, int N){
	}

	public int put(int mID, int mRow, int mCol, int mHeight, int mWidth){
	    return 0;
	}

	public int getCount(int mID){
	    return 0;
	}

	public int countGroup(){
	    return 0;
	}
}