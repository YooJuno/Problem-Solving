// Main.java
import java.io.*;
import java.util.*;

public class Main {
	private static final int CMD_INIT = 1;
	private static final int CMD_PUT = 2;
	private static final int CMD_GET = 3;
	private static final int CMD_CNT = 4;

	private static UserSolution userSolution = new UserSolution();

	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;

	public static boolean run(BufferedReader br) throws IOException {
		int Q = Integer.parseInt(br.readLine());
		int ans, ret, mID;
		boolean okay = false;

		for (int q = 0; q < Q; q++) {
			st = new StringTokenizer(br.readLine());
			int cmd = Integer.parseInt(st.nextToken());
			
			switch (cmd) {
			case CMD_INIT:
				int L = Integer.parseInt(st.nextToken());
				int N = Integer.parseInt(st.nextToken());
				userSolution.init(L, N);
                okay = true; 
				break;
			case CMD_PUT:
				mID = Integer.parseInt(st.nextToken());
				int mRow = Integer.parseInt(st.nextToken());
				int mCol = Integer.parseInt(st.nextToken());
				int mHeight = Integer.parseInt(st.nextToken());
				int mWidth  = Integer.parseInt(st.nextToken());
				ret = userSolution.put(mID, mRow, mCol, mHeight, mWidth);
				ans = Integer.parseInt(st.nextToken());
				if (ret != ans)
					okay = false;
				break;
			case CMD_GET:
				mID = Integer.parseInt(st.nextToken());
				ret = userSolution.getCount(mID);
				ans = Integer.parseInt(st.nextToken());
				if (ret != ans)
					okay = false;
				break;
			case CMD_CNT:
				ret = userSolution.countGroup();
				ans = Integer.parseInt(st.nextToken());
				if (ret != ans)
					okay = false;
				break;
			default:
				okay = false;
				break;
			}
		}
		return okay;
	}

	public static void main(String[] args) throws IOException {
		st = new StringTokenizer(br.readLine());
		int TC = Integer.parseInt(st.nextToken());
		int MARK = Integer.parseInt(st.nextToken());

		for (int tc = 1; tc <= TC; ++tc) {
			boolean result = run(br);
			int score = result ? MARK : 0;
			System.out.println("#" + tc + " " + score);
		}
	}
}