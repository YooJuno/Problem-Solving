''' main.py '''
import sys
from solution import init, put, getCount, countGroup
 
INIT = 1
PUT  = 2
GET  = 3
CNT  = 4
 
def run():
    Q = int(input())
    okay = False
 
    for q in range(Q):
        input_iter = iter(sys.stdin.readline().split())
        cmd = int(next(input_iter))
        
        if cmd == INIT:
            L = int(next(input_iter))
            N = int(next(input_iter))
            init(L, N)
            okay = True
 
        elif cmd == PUT:
            mID = int(next(input_iter))
            mRow = int(next(input_iter))
            mCol = int(next(input_iter))
            mHeight = int(next(input_iter))
            mWidth = int(next(input_iter))
            ret = put(mID, mRow, mCol, mHeight, mWidth) 
            ans = int(next(input_iter))
            if ret != ans:
                okay = False
 
        elif cmd == GET:
            mID = int(next(input_iter))
            ret = getCount(mID)
            ans = int(next(input_iter))
            if ret != ans:
                okay = False
        
        elif cmd == CNT:
            ret = countGroup()
            ans = int(next(input_iter))
            if ret != ans:
                okay = False
        
        else:
            okay = False
 
    return okay
 
 
if __name__ == '__main__':
    #sys.stdin = open('input.txt')
    T, MARK = map(int, input().split())
 
    for tc in range(1, T + 1):
        score = MARK if run() else 0
        print("#%d %d" % (tc, score), flush=True)