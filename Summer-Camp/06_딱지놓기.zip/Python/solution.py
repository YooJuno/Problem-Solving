''' solution.py'''
def init(L:int, N:int) -> None:
    pass

def put(mID:int, mRow:int, mCol:int, mHeight:int, mWidth:int) -> int:
    pass

def getCount(mID:int) -> int:
    pass

def countGroup() -> int:
    pass